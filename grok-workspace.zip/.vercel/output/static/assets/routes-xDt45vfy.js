import{i as e,n as t,r as n,t as r}from"./index-B92GRAAp.js";var i=e(n()),a=`<div class="wrap">
  <div class="logo"><img src="/f1-logo.png" alt="Formel 1" height="40"><span id="tz" hidden></span></div>
  <div class="tabs"><button class="tab on" data-k="t">Termine</button><button class="tab" data-k="w">Meisterschaft</button><button class="tab" data-k="n">News</button></div>
  <div id="p-t">
  <div id="hero"></div>
  <div class="bar">
    <button class="chip on" data-f="ALL">Alle</button>
    <button class="chip" data-f="F1">Formel 1</button>
    <button class="chip" data-f="F2">Formel 2</button>
  </div>
  <div id="list"></div>
  <div class="bar" style="margin-top:6px">
    <button class="btn" id="past">Vergangene zeigen</button>
    <span class="sp"></span>
    <button class="btn" id="edit">Bearbeiten</button>
  </div>
  <div class="bar" id="editbar" style="display:none">
    <button class="btn pri" id="add">+ Termin</button>
    <span class="sp"></span>
    <button class="btn" id="reset">Zurücksetzen</button>
  </div>
  <div id="y27"></div>
  </div>
  <div id="p-w" style="display:none"><div class="bar"><button class="ch2 on" data-w="f1d">F1 Fahrer</button><button class="ch2" data-w="f1t">F1 Teams</button><button class="ch2" data-w="f2d">F2 Fahrer</button><button class="ch2" data-w="f2t">F2 Teams</button></div><div id="wmlist"></div></div>
  <div id="p-n" style="display:none"></div>
  <div class="foot">Änderungen werden nur auf diesem Gerät gespeichert.<br>Zeiten ohne Gewähr – bei Änderungen der Veranstalter bitte anpassen.<br><span id="st"></span></div>
</div>

<div class="modal" id="modal"><div class="sheet">
  <h3 id="mt">Termin</h3>
  <label>Serie</label>
  <select id="fs"><option>F1</option><option>F2</option></select>
  <label>Grand Prix / Ort</label>
  <input id="fg" placeholder="z. B. 🇺🇸 USA (Austin)">
  <label>Session</label>
  <input id="fn" list="sess" placeholder="z. B. Qualifying">
  <datalist id="sess"><option>1. Freies Training</option><option>2. Freies Training</option><option>3. Freies Training</option><option>Freies Training</option><option>Qualifying</option><option>Sprint-Qualifying</option><option>Sprint</option><option>Rennen</option><option>Sprint Race</option><option>Feature Race</option></datalist>
  <label>Datum &amp; Uhrzeit (deutsche Zeit)</label>
  <input id="fd" type="datetime-local">
  <div class="acts"><button class="btn" id="cancel">Abbrechen</button><button class="btn pri" id="save">Speichern</button></div>
</div></div>
`,o=t();function s(){return(0,i.useEffect)(()=>{let e=!1,t=()=>{};return r(()=>import(`./engine-Caz1Kp9z.js`).then(n=>{e||(t=n.startApp())}),[]),()=>{e=!0,t()}},[]),(0,o.jsx)(`div`,{suppressHydrationWarning:!0,dangerouslySetInnerHTML:{__html:a}})}export{s as component};