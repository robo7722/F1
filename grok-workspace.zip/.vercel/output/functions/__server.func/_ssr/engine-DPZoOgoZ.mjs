//#region node_modules/.nitro/vite/services/ssr/assets/engine-DPZoOgoZ.js
var TZ = "Europe/Berlin";
var DEF = [
	[
		"F1",
		"🇺🇸 USA (Austin)",
		"1. Freies Training",
		"2026-10-23T17:30:00Z"
	],
	[
		"F1",
		"🇺🇸 USA (Austin)",
		"2. Freies Training",
		"2026-10-23T21:00:00Z"
	],
	[
		"F1",
		"🇺🇸 USA (Austin)",
		"3. Freies Training",
		"2026-10-24T17:30:00Z"
	],
	[
		"F1",
		"🇺🇸 USA (Austin)",
		"Qualifying",
		"2026-10-24T21:00:00Z"
	],
	[
		"F1",
		"🇺🇸 USA (Austin)",
		"Rennen",
		"2026-10-25T19:00:00Z"
	],
	[
		"F1",
		"🇲🇽 Mexiko-Stadt",
		"1. Freies Training",
		"2026-10-30T18:30:00Z"
	],
	[
		"F1",
		"🇲🇽 Mexiko-Stadt",
		"2. Freies Training",
		"2026-10-30T22:00:00Z"
	],
	[
		"F1",
		"🇲🇽 Mexiko-Stadt",
		"3. Freies Training",
		"2026-10-31T17:30:00Z"
	],
	[
		"F1",
		"🇲🇽 Mexiko-Stadt",
		"Qualifying",
		"2026-10-31T21:00:00Z"
	],
	[
		"F1",
		"🇲🇽 Mexiko-Stadt",
		"Rennen",
		"2026-11-01T20:00:00Z"
	],
	[
		"F1",
		"🇧🇷 São Paulo",
		"1. Freies Training",
		"2026-11-06T15:30:00Z"
	],
	[
		"F1",
		"🇧🇷 São Paulo",
		"2. Freies Training",
		"2026-11-06T19:00:00Z"
	],
	[
		"F1",
		"🇧🇷 São Paulo",
		"3. Freies Training",
		"2026-11-07T14:30:00Z"
	],
	[
		"F1",
		"🇧🇷 São Paulo",
		"Qualifying",
		"2026-11-07T18:00:00Z"
	],
	[
		"F1",
		"🇧🇷 São Paulo",
		"Rennen",
		"2026-11-08T17:00:00Z"
	],
	[
		"F1",
		"🇺🇸 Las Vegas",
		"1. Freies Training",
		"2026-11-20T00:30:00Z"
	],
	[
		"F1",
		"🇺🇸 Las Vegas",
		"2. Freies Training",
		"2026-11-20T04:00:00Z"
	],
	[
		"F1",
		"🇺🇸 Las Vegas",
		"3. Freies Training",
		"2026-11-21T00:30:00Z"
	],
	[
		"F1",
		"🇺🇸 Las Vegas",
		"Qualifying",
		"2026-11-21T04:00:00Z"
	],
	[
		"F1",
		"🇺🇸 Las Vegas",
		"Rennen",
		"2026-11-22T04:00:00Z"
	],
	[
		"F1",
		"🇶🇦 Katar",
		"1. Freies Training",
		"2026-11-27T13:00:00Z"
	],
	[
		"F1",
		"🇶🇦 Katar",
		"2. Freies Training",
		"2026-11-27T17:00:00Z"
	],
	[
		"F1",
		"🇶🇦 Katar",
		"3. Freies Training",
		"2026-11-28T14:30:00Z"
	],
	[
		"F1",
		"🇶🇦 Katar",
		"Qualifying",
		"2026-11-28T18:00:00Z"
	],
	[
		"F1",
		"🇶🇦 Katar",
		"Rennen",
		"2026-11-29T16:00:00Z"
	],
	[
		"F2",
		"🇶🇦 Katar",
		"Freies Training",
		"2026-11-27T08:55:00Z",
		1
	],
	[
		"F2",
		"🇶🇦 Katar",
		"Qualifying",
		"2026-11-27T12:55:00Z",
		1
	],
	[
		"F2",
		"🇶🇦 Katar",
		"Sprint Race",
		"2026-11-28T07:35:00Z",
		1
	],
	[
		"F2",
		"🇶🇦 Katar",
		"Feature Race",
		"2026-11-29T07:40:00Z",
		1
	],
	[
		"F1",
		"🇦🇪 Abu Dhabi",
		"1. Freies Training",
		"2026-12-04T09:30:00Z",
		1
	],
	[
		"F1",
		"🇦🇪 Abu Dhabi",
		"2. Freies Training",
		"2026-12-04T13:00:00Z",
		1
	],
	[
		"F1",
		"🇦🇪 Abu Dhabi",
		"3. Freies Training",
		"2026-12-05T10:30:00Z",
		1
	],
	[
		"F1",
		"🇦🇪 Abu Dhabi",
		"Qualifying",
		"2026-12-05T14:00:00Z"
	],
	[
		"F1",
		"🇦🇪 Abu Dhabi",
		"Rennen",
		"2026-12-06T13:00:00Z"
	],
	[
		"F2",
		"🇦🇪 Abu Dhabi",
		"Freies Training",
		"2026-12-04T07:55:00Z",
		1
	],
	[
		"F2",
		"🇦🇪 Abu Dhabi",
		"Qualifying",
		"2026-12-04T11:55:00Z",
		1
	],
	[
		"F2",
		"🇦🇪 Abu Dhabi",
		"Sprint Race",
		"2026-12-05T06:35:00Z",
		1
	],
	[
		"F2",
		"🇦🇪 Abu Dhabi",
		"Feature Race",
		"2026-12-06T06:40:00Z",
		1
	]
];
var WX = { "🇺🇸 USA (Austin)": {
	q: "☀️ ca. 29 °C, trocken (Regen 0 %)",
	r: "⛅ ca. 27–29 °C, Regen 7–20 %, Wind bis 40 km/h",
	u: "21.10."
} };
var STD = {
	f1d: {
		s: "Formel 1 · Fahrer · Stand nach Singapur (11.10.)",
		r: [
			[
				"Kimi Antonelli",
				"Mercedes",
				340
			],
			[
				"George Russell",
				"Mercedes",
				238
			],
			[
				"Lewis Hamilton",
				"Ferrari",
				229
			],
			[
				"Max Verstappen",
				"Red Bull",
				221
			],
			[
				"Charles Leclerc",
				"Ferrari",
				215
			],
			[
				"Lando Norris",
				"McLaren",
				201
			],
			[
				"Oscar Piastri",
				"McLaren",
				138
			],
			[
				"Isack Hadjar",
				"Red Bull",
				97
			],
			[
				"Liam Lawson",
				"Racing Bulls",
				75
			],
			[
				"Pierre Gasly",
				"Alpine",
				41
			],
			[
				"Arvid Lindblad",
				"Racing Bulls",
				38
			],
			[
				"Franco Colapinto",
				"Alpine",
				27
			],
			[
				"Oliver Bearman",
				"Haas",
				23
			],
			[
				"Nico Hülkenberg",
				"Audi",
				13
			],
			[
				"Gabriel Bortoleto",
				"Audi",
				10
			],
			[
				"Esteban Ocon",
				"Haas",
				7
			],
			[
				"Fernando Alonso",
				"Aston Martin",
				7
			],
			[
				"Carlos Sainz",
				"Williams",
				7
			],
			[
				"Alex Albon",
				"Williams",
				5
			],
			[
				"Yuki Tsunoda",
				"Racing Bulls",
				1
			],
			[
				"Lance Stroll",
				"Aston Martin",
				0
			],
			[
				"Valtteri Bottas",
				"Cadillac",
				0
			],
			[
				"Sergio Pérez",
				"Cadillac",
				0
			]
		]
	},
	f1t: {
		s: "Formel 1 · Teams · Stand nach Singapur (11.10.) – Quellen weichen bei Red Bull/Racing Bulls leicht ab",
		r: [
			[
				"Mercedes",
				"",
				578
			],
			[
				"Ferrari",
				"",
				444
			],
			[
				"McLaren",
				"",
				339
			],
			[
				"Red Bull",
				"",
				332
			],
			[
				"Racing Bulls",
				"",
				100
			],
			[
				"Alpine",
				"",
				68
			],
			[
				"Haas",
				"",
				30
			],
			[
				"Audi",
				"",
				23
			],
			[
				"Williams",
				"",
				12
			],
			[
				"Aston Martin",
				"",
				7
			],
			[
				"Cadillac",
				"",
				0
			]
		]
	},
	f2d: {
		s: "Formel 2 · Fahrer · Stand nach Baku (26.09.)",
		r: [
			[
				"Rafael Câmara",
				"Invicta Racing",
				207
			],
			[
				"Nikola Tsolov",
				"Campos Racing",
				200
			],
			[
				"Alex Dunne",
				"Rodin Motorsport",
				189
			],
			[
				"Gabriele Minì",
				"MP Motorsport",
				163
			],
			[
				"Dino Beganovic",
				"DAMS Lucas Oil",
				137
			],
			[
				"Noel León",
				"Campos Racing",
				133
			],
			[
				"Martinius Stenshorne",
				"Rodin Motorsport",
				107
			],
			[
				"Joshua Dürksen",
				"Invicta Racing",
				90
			],
			[
				"Kush Maini",
				"ART Grand Prix",
				90
			],
			[
				"Laurens van Hoepen",
				"Trident",
				90
			],
			[
				"Tasanapol Inthraphuvasak",
				"ART Grand Prix",
				71
			],
			[
				"Ritomo Miyata",
				"Hitech",
				70
			],
			[
				"Rafael Villagómez",
				"Van Amersfoort",
				42
			],
			[
				"John Bennett",
				"Trident",
				38
			],
			[
				"Oliver Goethe",
				"MP Motorsport",
				37
			],
			[
				"Roman Bilinski",
				"DAMS Lucas Oil",
				36
			],
			[
				"Sebastián Montoya",
				"Prema",
				30
			],
			[
				"Emerson Fittipaldi Jr.",
				"AIX Racing",
				28
			],
			[
				"Colton Herta",
				"Hitech",
				26
			],
			[
				"Mari Boya",
				"Prema",
				21
			],
			[
				"Nico Varrone",
				"Van Amersfoort",
				15
			],
			[
				"Cian Shields",
				"AIX Racing",
				10
			],
			[
				"Hiyu Yamakoshi",
				"Van Amersfoort",
				2
			]
		]
	},
	f2t: {
		s: "Formel 2 · Teams · Stand nach Baku (26.09.)",
		r: [
			[
				"Campos Racing",
				"",
				333
			],
			[
				"Invicta Racing",
				"",
				297
			],
			[
				"Rodin Motorsport",
				"",
				296
			],
			[
				"MP Motorsport",
				"",
				200
			],
			[
				"DAMS Lucas Oil",
				"",
				173
			],
			[
				"ART Grand Prix",
				"",
				161
			],
			[
				"Trident",
				"",
				128
			],
			[
				"Hitech",
				"",
				96
			],
			[
				"Van Amersfoort",
				"",
				59
			],
			[
				"Prema",
				"",
				51
			],
			[
				"AIX Racing",
				"",
				38
			]
		]
	}
};
var NEWS = [
	[
		"22.10.",
		"F1",
		"Antonelli kann in Austin Weltmeister werden",
		"Mit 102 Punkten Vorsprung braucht er den Sieg, dazu Russell nur auf Platz 9 oder schlechter und Hamilton auf Platz 5 oder schlechter."
	],
	[
		"21.10.",
		"F1",
		"Mercedes bringt Update nach Austin",
		"Beide Autos fahren die neueste W17-Spezifikation. Teamchef Wolff mahnt, nicht übermütig zu werden."
	],
	[
		"20.10.",
		"F1",
		"Verstappen auf Siegesserie",
		"Nach den Siegen in Malaysia und Singapur kann er in Austin mit einem fünften COTA-Sieg Hamiltons Rekord einstellen."
	],
	[
		"20.10.",
		"F1",
		"Cadillac: Herta im 1. Training",
		"Colton Herta ersetzt im Freitagstraining in Austin Sergio Pérez."
	],
	[
		"20.10.",
		"F1",
		"Rennen ab 2028 wieder länger",
		"Die Formel 1 plant die Rückkehr zu 305-km-Grands-Prix, 2027 sind vorübergehend 290 km vorgesehen."
	],
	[
		"Okt.",
		"F2",
		"Câmara führt vor Tsolov",
		"Nur sieben Punkte trennen die beiden. In Katar und Abu Dhabi sind noch 78 Punkte zu holen, die FIA erwartet beide Rennen wie geplant."
	]
];
var ev = [];
var filt = "ALL";
var showPast = false;
var editing = false;
var editId = null;
var UKEY = "f1app.user.v3";
var HKEY = "f1app.hide.v3";
var base = [];
var user = [];
var hide = {};
function mk(a) {
	return {
		id: "b|" + a[0] + "|" + a[1] + "|" + a[2],
		s: a[0],
		g: a[1],
		n: a[2],
		t: Date.parse(a[3]),
		p: a[4] || 0
	};
}
function rd(k, d) {
	try {
		var r = localStorage.getItem(k);
		if (r) return JSON.parse(r);
	} catch (e) {}
	return d;
}
function wr(k, v) {
	try {
		localStorage.setItem(k, JSON.stringify(v));
	} catch (e) {}
}
function build() {
	ev = base.filter(function(e) {
		return !hide[e.id];
	}).concat(user);
}
function load() {
	base = DEF.map(mk);
	user = rd(UKEY, []);
	hide = rd(HKEY, {});
	if (!Array.isArray(user)) user = [];
	build();
}
function store() {
	wr(UKEY, user);
	wr(HKEY, hide);
	build();
}
function parts(ts) {
	var o = {};
	new Intl.DateTimeFormat("en-GB", {
		timeZone: TZ,
		hourCycle: "h23",
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}).formatToParts(ts).forEach(function(p) {
		o[p.type] = p.value;
	});
	return o;
}
function toInput(ts) {
	var p = parts(ts);
	return p.year + "-" + p.month + "-" + p.day + "T" + p.hour + ":" + p.minute;
}
function fromInput(v) {
	var m = v.match(/(\d+)-(\d+)-(\d+)T(\d+):(\d+)/);
	if (!m) return NaN;
	var base = Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5]);
	var g = base;
	for (var i = 0; i < 3; i++) {
		var p = parts(g);
		g = base - (Date.UTC(+p.year, p.month - 1, +p.day, +p.hour, +p.minute) - g);
	}
	return g;
}
var fDay = new Intl.DateTimeFormat("de-DE", {
	timeZone: TZ,
	weekday: "short",
	day: "2-digit",
	month: "2-digit"
});
var fTime = new Intl.DateTimeFormat("de-DE", {
	timeZone: TZ,
	hour: "2-digit",
	minute: "2-digit"
});
var fShort = new Intl.DateTimeFormat("de-DE", {
	timeZone: TZ,
	day: "numeric",
	month: "short"
});
function esc(s) {
	return String(s).replace(/[&<>"]/g, function(c) {
		return {
			"&": "&amp;",
			"<": "&lt;",
			">": "&gt;",
			"\"": "&quot;"
		}[c];
	});
}
function vis() {
	var now = Date.now();
	return ev.filter(function(e) {
		return (filt === "ALL" || e.s === filt) && (showPast || e.t >= now - 108e5);
	}).sort(function(a, b) {
		return a.t - b.t;
	});
}
function render() {
	var now = Date.now(), list = vis(), groups = {}, order = [];
	list.forEach(function(e) {
		if (!groups[e.g]) {
			groups[e.g] = [];
			order.push(e.g);
		}
		groups[e.g].push(e);
	});
	var h = "";
	order.forEach(function(g) {
		var a = groups[g], first = a[0].t, last = a[a.length - 1].t;
		var rng = fShort.format(first) + (fShort.format(first) !== fShort.format(last) ? " – " + fShort.format(last) : "");
		h += "<div class=\"gp\"><h2><div class=\"gt\">" + esc(g) + "<span>" + rng + "</span></div>" + trkSvg(g) + "</h2>" + wxLine(g);
		var ld = "";
		a.forEach(function(e) {
			var past = e.t < now, dk = fDay.format(e.t);
			if (dk !== ld) {
				ld = dk;
				h += "<div class=\"dh\">" + dk + "</div>";
			}
			h += "<div class=\"row" + (past ? " past" : "") + "\"><span class=\"tag " + e.s + "\">" + e.s + "</span><div class=\"s\"><b>" + esc(e.n) + "</b></div><div class=\"tm\"><b>" + (e.p === 2 ? "Zeit offen" : fTime.format(e.t) + " Uhr") + "</b>" + (e.p === 1 ? "<span>vorläufig</span>" : "") + "</div>" + (editing ? "<button class=\"ic\" data-e=\"" + esc(e.id) + "\">✎</button><button class=\"ic\" data-x=\"" + esc(e.id) + "\">✕</button>" : "") + "</div>";
		});
		h += "</div>";
	});
	document.getElementById("list").innerHTML = h || "<div class=\"empty\">Keine anstehenden Termine.<br>Mit „Bearbeiten“ kannst du neue hinzufügen.</div>";
	render27();
	hero();
}
var heroKey = "";
function ccOf(g) {
	var a = Array.from(g || "");
	if (a.length < 2) return "";
	var x = a[0].codePointAt(0), y = a[1].codePointAt(0);
	if (x < 127462 || x > 127487 || y < 127462 || y > 127487) return "";
	return String.fromCharCode(x - 127462 + 97, y - 127462 + 97);
}
function noFlag(s) {
	return String(s).replace(/[\u{1F1E6}-\u{1F1FF}]{2}\uFE0F?\s*/gu, "").trim();
}
function hero() {
	var now = Date.now(), nx = ev.filter(function(e) {
		return e.t > now && e.p !== 2 && (filt === "ALL" || e.s === filt);
	}).sort(function(a, b) {
		return a.t - b.t;
	})[0];
	var el = document.getElementById("hero");
	if (!nx) {
		el.innerHTML = "";
		heroKey = "";
		return;
	}
	var d = nx.t - now, v = [
		Math.floor(d / 864e5),
		Math.floor(d % 864e5 / 36e5),
		Math.floor(d % 36e5 / 6e4),
		Math.floor(d % 6e4 / 1e3)
	];
	var key = nx.id + "|" + nx.t;
	if (key !== heroKey) {
		heroKey = key;
		var cc = ccOf(nx.g);
		el.innerHTML = "<div class=\"hero\"><div class=\"bg\"" + (cc ? " style=\"background-image:url(https://flagcdn.com/w640/" + cc + ".png)\"" : "") + "></div><div class=\"ov\"></div><div class=\"hc\"><small>Als Nächstes · " + nx.s + "</small><div class=\"t\">" + esc(noFlag(nx.g)) + " – " + esc(nx.n) + "</div><div class=\"d\">" + fDay.format(nx.t) + ", " + fTime.format(nx.t) + " Uhr</div><div class=\"cd\"><div><b id=\"cd0\"></b><span>Tage</span></div><div><b id=\"cd1\"></b><span>Std</span></div><div><b id=\"cd2\"></b><span>Min</span></div><div><b id=\"cd3\"></b><span>Sek</span></div></div></div></div>";
	}
	for (var i = 0; i < 4; i++) {
		var c = document.getElementById("cd" + i);
		if (c) c.textContent = v[i];
	}
}
function $(i) {
	return document.getElementById(i);
}
function openM(e) {
	editId = e ? e.id : null;
	$("mt").textContent = e ? "Termin bearbeiten" : "Neuer Termin";
	$("fs").value = e ? e.s : "F1";
	$("fg").value = e ? e.g : "";
	$("fn").value = e ? e.n : "";
	$("fd").value = e ? toInput(e.t) : "";
	$("modal").classList.add("show");
}
function closeM() {
	$("modal").classList.remove("show");
}
var wm = "f1d";
function wxLine(g) {
	var w = WXL[g] || WX[g];
	return "<div class=\"wx\">" + (w ? "<b>Quali:</b> " + w.q + "<br><b>Rennen:</b> " + w.r + " <span>(Stand " + w.u + ")</span>" : "Wetterprognose folgt ca. 5 Tage vor dem Wochenende") + "</div>";
}
function wmRender() {
	var d = STD[wm], h = "<div class=\"sub\">" + esc(d.s) + "</div><div class=\"gp\">";
	d.r.forEach(function(r, i) {
		h += "<div class=\"row\" style=\"" + (i ? "" : "border-top:0") + "\"><span class=\"pos\">" + (i + 1) + "</span><div class=\"s\"><b>" + esc(r[0]) + "</b>" + (r[1] ? "<i>" + esc(r[1]) + "</i>" : "") + "</div><div class=\"tm\"><b>" + r[2] + "</b><span>Pkt</span></div></div>";
	});
	$("wmlist").innerHTML = h + "</div>";
}
function newsRender() {
	var h = "";
	if (NEWSL && NEWSL.length) h = NEWSL.map(function(n) {
		return "<div class=\"nw\"><small><span class=\"tag " + n.s + "\">" + n.s + "</span> " + fNews.format(n.t) + (n.src ? " · " + esc(n.src) : "") + "</small><h3><a href=\"" + esc(n.u) + "\" target=\"_blank\" rel=\"noopener\">" + esc(n.title) + "</a></h3></div>";
	}).join("") + "<div class=\"foot\">Live-Schlagzeilen (Google News) · Abruf " + NEWST + "</div>";
	else h = NEWS.map(function(n) {
		return "<div class=\"nw\"><small><span class=\"tag " + n[1] + "\">" + n[1] + "</span> " + n[0] + "</small><h3>" + esc(n[2]) + "</h3><p>" + esc(n[3]) + "</p></div>";
	}).join("") + "<div class=\"foot\">Stand: 22.10.2026 · Live-Abruf gerade nicht möglich</div>";
	$("p-n").innerHTML = h;
}
var WXL = {};
var COORD = {
	"🇺🇸 USA (Austin)": [30.1328, -97.6411],
	"🇲🇽 Mexiko-Stadt": [19.4042, -99.0907],
	"🇧🇷 São Paulo": [-23.7036, -46.6997],
	"🇺🇸 Las Vegas": [36.1147, -115.1728],
	"🇶🇦 Katar": [25.49, 51.4542],
	"🇦🇪 Abu Dhabi": [24.4672, 54.6031]
};
function wIcon(c) {
	return c === 0 ? "☀️" : c <= 2 ? "⛅" : c === 3 ? "☁️" : c <= 48 ? "🌫️" : c <= 67 ? "🌧️" : c <= 77 ? "❄️" : c <= 82 ? "🌦️" : "⛈️";
}
function unwrap(u) {
	return fetch("/api/fetch?url=" + encodeURIComponent(u)).then(function(r) {
		if (!r.ok) throw new Error("HTTP " + r.status);
		return r.json();
	}).then(function(w) {
		if (!w || w.status < 200 || w.status >= 300) throw new Error("HTTP " + (w && w.status || 0));
		return w.text;
	});
}
function getJ(u) {
	return unwrap(u).then(function(t) {
		return JSON.parse(t);
	});
}
function nowT() {
	return (/* @__PURE__ */ new Date()).toLocaleTimeString("de-DE", {
		hour: "2-digit",
		minute: "2-digit",
		timeZone: TZ
	}) + " Uhr";
}
function loadStd() {
	var A = "https://api.jolpi.ca/ergast/f1/current/";
	return Promise.all([getJ(A + "driverstandings.json"), getJ(A + "constructorstandings.json")]).then(function(x) {
		var dl = x[0].MRData.StandingsTable.StandingsLists[0].DriverStandings, cl = x[1].MRData.StandingsTable.StandingsLists[0].ConstructorStandings, t = nowT();
		STD.f1d = {
			s: "Formel 1 · Fahrer · live (Abruf " + t + ")",
			r: dl.map(function(d) {
				var c = d.Constructors || [];
				return [
					d.Driver.givenName + " " + d.Driver.familyName,
					c.length ? c[c.length - 1].name : "",
					+d.points
				];
			})
		};
		STD.f1t = {
			s: "Formel 1 · Teams · live (Abruf " + t + ")",
			r: cl.map(function(c) {
				return [
					c.Constructor.name,
					"",
					+c.points
				];
			})
		};
		stat("f1", 1);
		wmRender();
	}).catch(function() {
		stat("f1", 0);
	});
}
function loadWx() {
	var gps = {};
	ev.forEach(function(e) {
		if (e.s === "F1" && COORD[e.g]) gps[e.g] = 1;
	});
	Object.keys(gps).forEach(function(g) {
		var c = COORD[g];
		getJ("https://api.open-meteo.com/v1/forecast?latitude=" + c[0] + "&longitude=" + c[1] + "&hourly=temperature_2m,precipitation_probability,weathercode&timezone=" + encodeURIComponent(TZ) + "&forecast_days=16").then(function(j) {
			var H = j.hourly, o = {};
			ev.forEach(function(e) {
				if (e.g !== g || e.s !== "F1" || e.n !== "Qualifying" && e.n !== "Rennen") return;
				var k = H.time.indexOf(toInput(e.t).slice(0, 13) + ":00");
				if (k < 0) return;
				var pr = H.precipitation_probability[k];
				o[e.n === "Rennen" ? "r" : "q"] = wIcon(H.weathercode[k]) + " " + Math.round(H.temperature_2m[k]) + " °C, Regen " + (pr == null ? "?" : pr) + " %";
			});
			if (o.q || o.r) {
				o.q = o.q || "–";
				o.r = o.r || "–";
				o.u = nowT();
				WXL[g] = o;
				stat("w", 1);
				render();
			}
		}).catch(function() {
			if (!("w" in ST)) stat("w", 0);
		});
	});
}
var ST = {};
var STN = {
	z: "Zeitplan",
	f1: "F1-Tabellen",
	f2: "F2-Tabellen",
	n: "News",
	w: "Wetter",
	s: "Strecken"
};
var WHY = {};
function stat(k, ok, why) {
	ST[k] = ok;
	if (why !== void 0) WHY[k] = String(why && why.message || why);
	var h = Object.keys(STN).filter(function(x) {
		return x in ST;
	}).map(function(x) {
		return STN[x] + (ST[x] ? " ✔ live" : " ⚠ gespeichert" + (WHY[x] ? " (" + WHY[x] + ")" : ""));
	}).join(" · ");
	var el = $("st");
	if (el) el.textContent = h;
}
var CIRC = {
	americas: "🇺🇸 USA (Austin)",
	rodriguez: "🇲🇽 Mexiko-Stadt",
	interlagos: "🇧🇷 São Paulo",
	vegas: "🇺🇸 Las Vegas",
	losail: "🇶🇦 Katar",
	yas_marina: "🇦🇪 Abu Dhabi"
};
var SESS = [
	["FirstPractice", "1. Freies Training"],
	["SecondPractice", "2. Freies Training"],
	["ThirdPractice", "3. Freies Training"],
	["SprintQualifying", "Sprint-Qualifying"],
	["Sprint", "Sprint"],
	["Qualifying", "Qualifying"]
];
function nearG(rt) {
	var g = null;
	DEF.forEach(function(a) {
		if (a[0] === "F1" && a[2] === "Rennen" && Math.abs(Date.parse(a[3]) - rt) < 1728e5) g = a[1];
	});
	return g;
}
function loadSched() {
	return getJ("https://api.jolpi.ca/ergast/f1/current.json?limit=40").then(function(j) {
		var R = j.MRData.RaceTable.Races, L = [], now = Date.now();
		function add(g, n, d, t) {
			if (!d || !t) return;
			var ts = Date.parse(d + "T" + t);
			if (!isNaN(ts)) L.push(mk([
				"F1",
				g,
				n,
				new Date(ts).toISOString()
			]));
		}
		R.forEach(function(r) {
			var rt = Date.parse(r.date + "T" + (r.time || "")), g;
			if (isNaN(rt) || rt < now - 3456e5) return;
			g = CIRC[r.Circuit.circuitId] || nearG(rt) || "🏁 " + r.raceName;
			SESS.forEach(function(s) {
				if (r[s[0]]) add(g, s[1], r[s[0]].date, r[s[0]].time);
			});
			add(g, "Rennen", r.date, r.time);
		});
		if (!L.length) throw 0;
		var ids = {};
		L.forEach(function(e) {
			ids[e.id] = 1;
		});
		base = base.filter(function(e) {
			return !(e.s === "F1" && ids[e.id]);
		}).concat(L);
		build();
		render();
		loadWx();
	});
}
function nrm(s) {
	return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}
function cellTxt(c) {
	return c.textContent.replace(/\[[^\]]*\]/g, "").replace(/\s+/g, " ").trim();
}
function wikiRows(html, kind) {
	var d = new DOMParser().parseFromString(html, "text/html"), best = [];
	Array.prototype.forEach.call(d.querySelectorAll("table.wikitable"), function(t) {
		if (!t.rows.length) return;
		var hd = t.rows[0].textContent;
		if (!/Pos/i.test(hd) || (kind === "d" ? !/Driver/i.test(hd) || /Team|Entrant/i.test(hd) : !/Team|Entrant/i.test(hd))) return;
		var span = !!t.querySelector("td[rowspan],th[rowspan]"), out = [];
		Array.prototype.forEach.call(t.rows, function(r) {
			var c = r.cells;
			if (c.length < 3 || !/^\d{1,2}$/.test(cellTxt(c[0]))) return;
			if (kind === "t" && span && c[0].rowSpan < 2) return;
			var nm = cellTxt(c[1]), pt = parseFloat(cellTxt(c[c.length - 1]).replace(/[^\d.]/g, ""));
			if (nm && !isNaN(pt)) out.push([
				nm,
				"",
				pt
			]);
		});
		if (out.length > best.length) best = out;
	});
	return best;
}
function goodRows(rows, min, ref) {
	if (rows.length < min || rows[0][2] < ref) return false;
	for (var i = 1; i < rows.length; i++) if (rows[i][2] > rows[i - 1][2]) return false;
	return true;
}
function loadF2() {
	return getJ("https://en.wikipedia.org/w/api.php?format=json&formatversion=2&origin=*&action=parse&prop=text&redirects=1&page=2026_Formula_2_Championship").then(function(x) {
		var h = x.parse.text, t = nowT(), ok = false, tm = {};
		STD.f2d.r.forEach(function(r) {
			tm[nrm(r[0])] = r[1];
		});
		var dr = wikiRows(h, "d");
		if (goodRows(dr, 10, STD.f2d.r[0][2])) {
			STD.f2d = {
				s: "Formel 2 · Fahrer · live (Wikipedia, Abruf " + t + ")",
				r: dr.map(function(r) {
					return [
						r[0],
						tm[nrm(r[0])] || "",
						r[2]
					];
				})
			};
			ok = true;
		}
		var tr = wikiRows(h, "t");
		if (goodRows(tr, 5, STD.f2t.r[0][2])) {
			STD.f2t = {
				s: "Formel 2 · Teams · live (Wikipedia, Abruf " + t + ")",
				r: tr
			};
			ok = true;
		}
		if (!ok) throw new Error("Tabelle nicht erkannt (" + dr.length + "/" + tr.length + " Zeilen)");
		wmRender();
	});
}
var NEWSL = null;
var NEWST = "";
var fNews = new Intl.DateTimeFormat("de-DE", {
	timeZone: TZ,
	day: "2-digit",
	month: "2-digit",
	hour: "2-digit",
	minute: "2-digit"
});
function rss(u) {
	return "https://api.rss2json.com/v1/api.json?rss_url=" + encodeURIComponent(u);
}
var FEEDS = {
	F1: [
		"https://news.google.com/rss/search?q=Formel+1+when:3d&hl=de&gl=DE&ceid=DE:de",
		"https://de.motorsport.com/rss/f1/news/",
		"https://www.motorsport.com/rss/f1/news/"
	],
	F2: ["https://news.google.com/rss/search?q=%22Formel+2%22+when:14d&hl=de&gl=DE&ceid=DE:de", "https://de.motorsport.com/rss/f2/news/"]
};
function mapIt(k, it) {
	var ti = it.title || "", src = "", q = ti.lastIndexOf(" - ");
	if (q > 0) {
		src = ti.slice(q + 3);
		ti = ti.slice(0, q);
	} else src = "motorsport.com";
	return {
		s: k,
		title: ti,
		src,
		u: it.link,
		t: Date.parse(String(it.pubDate).replace(/^(\d{4}-\d\d-\d\d) /, "$1T").replace(/^(\d{4}-\d\d-\d\dT[\d:]+)$/, "$1Z"))
	};
}
function viaJson(u, k, n) {
	return getJ(rss(u)).then(function(j) {
		if (j.status !== "ok" || !j.items || !j.items.length) throw new Error(j.message || "leer");
		return j.items.slice(0, n).map(function(it) {
			return mapIt(k, it);
		});
	});
}
function viaXml(u, k, n) {
	return unwrap(u).then(function(x) {
		var d = new DOMParser().parseFromString(x, "text/xml"), a = Array.prototype.slice.call(d.querySelectorAll("item")).slice(0, n);
		if (!a.length) throw new Error("leer");
		return a.map(function(it) {
			var g = function(t) {
				var e = it.getElementsByTagName(t)[0];
				return e ? e.textContent : "";
			};
			return mapIt(k, {
				title: g("title"),
				link: g("link"),
				pubDate: g("pubDate")
			});
		});
	});
}
function feed(k, n) {
	var L = FEEDS[k], tries = [];
	L.forEach(function(u) {
		tries.push(function() {
			return viaJson(u, k, n);
		});
		tries.push(function() {
			return viaXml(u, k, n);
		});
	});
	var i = 0, err = null;
	function nx() {
		if (i >= tries.length) return Promise.reject(err || /* @__PURE__ */ new Error("keine Quelle"));
		return tries[i++]().catch(function(e) {
			err = e;
			return nx();
		});
	}
	return nx();
}
function loadNews() {
	var e1 = null;
	return Promise.all([feed("F1", 14).catch(function(e) {
		e1 = e;
		return [];
	}), feed("F2", 5).catch(function() {
		return [];
	})]).then(function(a) {
		var all = a[0].concat(a[1]).filter(function(n) {
			return n.title && /^https?:/.test(n.u || "") && !isNaN(n.t);
		}).sort(function(x, y) {
			return y.t - x.t;
		});
		if (!all.length) throw e1 || /* @__PURE__ */ new Error("keine Meldungen");
		NEWSL = all;
		NEWST = nowT();
		newsRender();
	});
}
var Y27 = [
	[
		"🇧🇭",
		"Bahrain",
		"12.–14. März",
		1,
		[26.0325, 50.5106]
	],
	[
		"🇸🇦",
		"Saudi-Arabien (Dschidda)",
		"19.–21. März",
		0,
		[21.6319, 39.1044]
	],
	[
		"🇦🇺",
		"Australien (Melbourne)",
		"2.–4. April",
		1,
		[-37.8497, 144.968]
	],
	[
		"🇯🇵",
		"Japan (Suzuka)",
		"9.–11. April",
		1,
		[34.8431, 136.541]
	],
	[
		"🇨🇳",
		"China (Shanghai)",
		"16.–18. April",
		0,
		[31.3389, 121.22]
	],
	[
		"🇺🇸",
		"Miami",
		"30. April – 2. Mai",
		0,
		[25.9581, -80.2389]
	],
	[
		"🇨🇦",
		"Kanada (Montreal)",
		"21.–23. Mai",
		1,
		[45.5, -73.5228]
	],
	[
		"🇲🇨",
		"Monaco",
		"4.–6. Juni",
		1,
		[43.7347, 7.4206]
	],
	[
		"🇵🇹",
		"Portugal (Portimão)",
		"18.–20. Juni",
		0,
		[37.227, -8.6267]
	],
	[
		"🇬🇧",
		"Großbritannien (Silverstone)",
		"2.–4. Juli",
		1,
		[52.0786, -1.0169]
	],
	[
		"🇦🇹",
		"Österreich (Spielberg)",
		"9.–11. Juli",
		0,
		[47.2197, 14.7647]
	],
	[
		"🇧🇪",
		"Belgien (Spa)",
		"23.–25. Juli",
		0,
		[50.4372, 5.9714]
	],
	[
		"🇭🇺",
		"Ungarn (Budapest)",
		"30. Juli – 1. August",
		0,
		[47.5789, 19.2486]
	],
	[
		"🇮🇹",
		"Italien (Monza)",
		"3.–5. September",
		1,
		[45.6156, 9.2811]
	],
	[
		"🇪🇸",
		"Spanien (Madrid)",
		"10.–12. September",
		0,
		null
	],
	[
		"🇦🇿",
		"Aserbaidschan (Baku)",
		"24.–26. September",
		0,
		[40.3725, 49.8533]
	],
	[
		"🇹🇷",
		"Türkei (Istanbul)",
		"1.–3. Oktober",
		0,
		[40.9517, 29.4058]
	],
	[
		"🇸🇬",
		"Singapur",
		"8.–10. Oktober",
		0,
		[1.2914, 103.864]
	],
	[
		"🇺🇸",
		"USA (Austin)",
		"22.–24. Oktober",
		0,
		[30.1328, -97.6411]
	],
	[
		"🇲🇽",
		"Mexiko-Stadt",
		"29.–31. Oktober",
		0,
		[19.4042, -99.0907]
	],
	[
		"🇧🇷",
		"São Paulo",
		"5.–7. November",
		1,
		[-23.7036, -46.6997]
	],
	[
		"🇺🇸",
		"Las Vegas",
		"18.–20. November",
		0,
		[36.1147, -115.1728]
	],
	[
		"🇶🇦",
		"Katar",
		"3.–5. Dezember",
		1,
		[25.49, 51.4542]
	],
	[
		"🇦🇪",
		"Abu Dhabi",
		"10.–12. Dezember",
		1,
		[24.4672, 54.6031]
	]
];
var ALLC = {};
Object.keys(COORD).forEach(function(k) {
	ALLC[k] = COORD[k];
});
Y27.forEach(function(r) {
	if (r[4]) ALLC["27|" + r[1]] = r[4];
});
var TP = rd("f1app.trk.v2", {});
var TPT = rd("f1app.trk.t", 0);
if (!TP || typeof TP !== "object") TP = {};
function trkSvg(k) {
	return TP[k] ? "<svg class=\"trk\" viewBox=\"0 0 100 60\" aria-hidden=\"true\"><path d=\"" + TP[k] + "\"/></svg>" : "";
}
function render27() {
	var el = $("y27");
	if (!el) return;
	if (filt === "F2") {
		el.innerHTML = "";
		return;
	}
	var h = "<div class=\"ny\"><div class=\"chk\"></div><h2>Saison <b>2027</b></h2><small>Geplanter Kalender · 24 Rennen · 10 Sprints · Termine können sich ändern</small></div><div class=\"gp\"><div class=\"row\" style=\"border-top:0\"><span class=\"tag F1\">TEST</span><div class=\"s\"><b>Wintertest Bahrain</b><i>24.–27. Februar</i></div></div>";
	Y27.forEach(function(r) {
		h += "<div class=\"row\"><span class=\"fl\">" + r[0] + "</span><div class=\"s\"><b>" + esc(r[1]) + (r[3] ? "<em class=\"spr\">Sprint</em>" : "") + "</b><i>" + r[2] + "</i></div>" + trkSvg("27|" + r[1]) + "</div>";
	});
	el.innerHTML = h + "</div>";
}
function trkPath(pts) {
	var k = Math.cos(pts[0][1] * Math.PI / 180), st = Math.max(1, Math.ceil(pts.length / 140)), q = [], i = 0;
	for (; i < pts.length; i += st) q.push([pts[i][0] * k, -pts[i][1]]);
	var a = 1e9, b = -1e9, c = 1e9, d = -1e9;
	q.forEach(function(p) {
		a = Math.min(a, p[0]);
		b = Math.max(b, p[0]);
		c = Math.min(c, p[1]);
		d = Math.max(d, p[1]);
	});
	var w = b - a || 1, h = d - c || 1, sc = Math.min(90 / w, 50 / h), ox = (100 - w * sc) / 2, oy = (60 - h * sc) / 2;
	return q.map(function(p, j) {
		return (j ? "L" : "M") + ((p[0] - a) * sc + ox).toFixed(1) + " " + ((p[1] - c) * sc + oy).toFixed(1);
	}).join("") + "Z";
}
function trkBuild(gj) {
	var cs = [];
	(gj.features || []).forEach(function(f) {
		var g = f.geometry;
		if (!g) return;
		var L = g.type === "LineString" ? [g.coordinates] : g.type === "MultiLineString" ? g.coordinates : [], pts = [].concat.apply([], L);
		if (pts.length < 20) return;
		var a = 1e9, b = -1e9, c = 1e9, d = -1e9;
		pts.forEach(function(p) {
			a = Math.min(a, p[0]);
			b = Math.max(b, p[0]);
			c = Math.min(c, p[1]);
			d = Math.max(d, p[1]);
		});
		cs.push({
			la: (c + d) / 2,
			lo: (a + b) / 2,
			p: pts
		});
	});
	var out = {};
	Object.keys(ALLC).forEach(function(k) {
		var t = ALLC[k], best = null, bd = .12;
		cs.forEach(function(x) {
			var dd = Math.max(Math.abs(x.la - t[0]), Math.abs(x.lo - t[1]));
			if (dd < bd) {
				bd = dd;
				best = x;
			}
		});
		if (best) out[k] = trkPath(best.p);
	});
	return out;
}
function loadTracks() {
	if (!Object.keys(ALLC).some(function(k) {
		return !TP[k];
	}) || Date.now() - TPT < 6048e5) return Promise.resolve();
	return getJ("https://raw.githubusercontent.com/bacinger/f1-circuits/master/f1-circuits.geojson").catch(function() {
		return getJ("https://cdn.jsdelivr.net/gh/bacinger/f1-circuits@master/f1-circuits.geojson");
	}).then(function(gj) {
		var o = trkBuild(gj);
		if (!Object.keys(o).length) throw new Error("keine Strecken erkannt");
		TP = o;
		wr("f1app.trk.v2", TP);
		wr("f1app.trk.t", Date.now());
		render();
	});
}
var lastLive = 0;
function loadLive() {
	lastLive = Date.now();
	loadSched().then(function() {
		stat("z", 1);
	}, function(e) {
		stat("z", 0, e);
		loadWx();
	});
	loadStd();
	loadF2().then(function() {
		stat("f2", 1);
	}, function(e) {
		stat("f2", 0, e);
	});
	loadNews().then(function() {
		stat("n", 1);
	}, function(e) {
		stat("n", 0, e);
	});
	loadTracks().then(function() {
		stat("s", 1);
	}, function(e) {
		stat("s", 0, e);
	});
}
var stopApp = null;
function startApp() {
	if (stopApp) return stopApp;
	document.querySelectorAll(".chip").forEach(function(c) {
		c.onclick = function() {
			filt = c.dataset.f;
			document.querySelectorAll(".chip").forEach(function(x) {
				x.classList.toggle("on", x === c);
			});
			render();
		};
	});
	$("past").onclick = function() {
		showPast = !showPast;
		this.textContent = showPast ? "Vergangene ausblenden" : "Vergangene zeigen";
		render();
	};
	$("edit").onclick = function() {
		editing = !editing;
		this.textContent = editing ? "Fertig" : "Bearbeiten";
		$("editbar").style.display = editing ? "flex" : "none";
		render();
	};
	$("add").onclick = function() {
		openM(null);
	};
	$("cancel").onclick = closeM;
	$("save").onclick = function() {
		var t = fromInput($("fd").value), g = $("fg").value.trim(), n = $("fn").value.trim();
		if (isNaN(t) || !g || !n) {
			alert("Bitte alle Felder ausfüllen.");
			return;
		}
		var o = {
			s: $("fs").value,
			g,
			n,
			t,
			p: 0
		};
		if (editId) {
			var u = user.filter(function(x) {
				return x.id === editId;
			})[0];
			if (u) {
				u.s = o.s;
				u.g = o.g;
				u.n = o.n;
				u.t = o.t;
			} else {
				hide[editId] = 1;
				o.id = "u" + Date.now();
				user.push(o);
			}
		} else {
			o.id = "u" + Date.now();
			user.push(o);
		}
		store();
		closeM();
		render();
	};
	$("reset").onclick = function() {
		if (confirm("Alle eigenen Änderungen verwerfen?")) {
			user = [];
			hide = {};
			store();
			render();
		}
	};
	$("list").onclick = function(e) {
		var b = e.target.closest("button");
		if (!b) return;
		if (b.dataset.e) openM(ev.filter(function(x) {
			return x.id === b.dataset.e;
		})[0]);
		if (b.dataset.x && confirm("Termin löschen?")) {
			var id = b.dataset.x;
			if (id.charAt(0) === "u") user = user.filter(function(x) {
				return x.id !== id;
			});
			else hide[id] = 1;
			store();
			render();
		}
	};
	try {
		var z = new Intl.DateTimeFormat("de-DE", {
			timeZone: TZ,
			timeZoneName: "short"
		}).formatToParts(Date.now()).filter(function(p) {
			return p.type === "timeZoneName";
		})[0];
		if (z) $("tz").textContent = z.value;
	} catch (e) {}
	document.querySelectorAll(".tab").forEach(function(b) {
		b.onclick = function() {
			var k = b.dataset.k;
			[
				"t",
				"w",
				"n"
			].forEach(function(x) {
				$("p-" + x).style.display = x === k ? "" : "none";
			});
			document.querySelectorAll(".tab").forEach(function(x) {
				x.classList.toggle("on", x === b);
			});
		};
	});
	document.querySelectorAll(".ch2").forEach(function(b) {
		b.onclick = function() {
			wm = b.dataset.w;
			document.querySelectorAll(".ch2").forEach(function(x) {
				x.classList.toggle("on", x === b);
			});
			wmRender();
		};
	});
	var onVis = function() {
		if (!document.hidden && Date.now() - lastLive > 3e5) loadLive();
	};
	document.addEventListener("visibilitychange", onVis);
	load();
	render();
	wmRender();
	newsRender();
	var t1 = setInterval(hero, 1e3), t2 = setInterval(render, 6e4);
	loadLive();
	var t3 = setInterval(loadLive, 9e5);
	if (typeof navigator !== "undefined" && "serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(function() {});
	stopApp = function() {
		clearInterval(t1);
		clearInterval(t2);
		clearInterval(t3);
		document.removeEventListener("visibilitychange", onVis);
		stopApp = null;
	};
	return stopApp;
}
//#endregion
export { startApp };
