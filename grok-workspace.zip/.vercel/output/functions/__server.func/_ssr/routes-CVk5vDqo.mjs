import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CVk5vDqo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var shell_default = "<div class=\"wrap\">\n  <div class=\"logo\"><img src=\"/f1-logo.png\" alt=\"Formel 1\" height=\"40\"><span id=\"tz\" hidden></span></div>\n  <div class=\"tabs\"><button class=\"tab on\" data-k=\"t\">Termine</button><button class=\"tab\" data-k=\"w\">Meisterschaft</button><button class=\"tab\" data-k=\"n\">News</button></div>\n  <div id=\"p-t\">\n  <div id=\"hero\"></div>\n  <div class=\"bar\">\n    <button class=\"chip on\" data-f=\"ALL\">Alle</button>\n    <button class=\"chip\" data-f=\"F1\">Formel 1</button>\n    <button class=\"chip\" data-f=\"F2\">Formel 2</button>\n  </div>\n  <div id=\"list\"></div>\n  <div class=\"bar\" style=\"margin-top:6px\">\n    <button class=\"btn\" id=\"past\">Vergangene zeigen</button>\n    <span class=\"sp\"></span>\n    <button class=\"btn\" id=\"edit\">Bearbeiten</button>\n  </div>\n  <div class=\"bar\" id=\"editbar\" style=\"display:none\">\n    <button class=\"btn pri\" id=\"add\">+ Termin</button>\n    <span class=\"sp\"></span>\n    <button class=\"btn\" id=\"reset\">Zurücksetzen</button>\n  </div>\n  <div id=\"y27\"></div>\n  </div>\n  <div id=\"p-w\" style=\"display:none\"><div class=\"bar\"><button class=\"ch2 on\" data-w=\"f1d\">F1 Fahrer</button><button class=\"ch2\" data-w=\"f1t\">F1 Teams</button><button class=\"ch2\" data-w=\"f2d\">F2 Fahrer</button><button class=\"ch2\" data-w=\"f2t\">F2 Teams</button></div><div id=\"wmlist\"></div></div>\n  <div id=\"p-n\" style=\"display:none\"></div>\n  <div class=\"foot\">Änderungen werden nur auf diesem Gerät gespeichert.<br>Zeiten ohne Gewähr – bei Änderungen der Veranstalter bitte anpassen.<br><span id=\"st\"></span></div>\n</div>\n\n<div class=\"modal\" id=\"modal\"><div class=\"sheet\">\n  <h3 id=\"mt\">Termin</h3>\n  <label>Serie</label>\n  <select id=\"fs\"><option>F1</option><option>F2</option></select>\n  <label>Grand Prix / Ort</label>\n  <input id=\"fg\" placeholder=\"z. B. 🇺🇸 USA (Austin)\">\n  <label>Session</label>\n  <input id=\"fn\" list=\"sess\" placeholder=\"z. B. Qualifying\">\n  <datalist id=\"sess\"><option>1. Freies Training</option><option>2. Freies Training</option><option>3. Freies Training</option><option>Freies Training</option><option>Qualifying</option><option>Sprint-Qualifying</option><option>Sprint</option><option>Rennen</option><option>Sprint Race</option><option>Feature Race</option></datalist>\n  <label>Datum &amp; Uhrzeit (deutsche Zeit)</label>\n  <input id=\"fd\" type=\"datetime-local\">\n  <div class=\"acts\"><button class=\"btn\" id=\"cancel\">Abbrechen</button><button class=\"btn pri\" id=\"save\">Speichern</button></div>\n</div></div>\n";
function Home() {
	(0, import_react.useEffect)(() => {
		let dead = false;
		let stop = () => {};
		import("./engine-DPZoOgoZ.mjs").then((mod) => {
			if (dead) return;
			stop = mod.startApp();
		});
		return () => {
			dead = true;
			stop();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		suppressHydrationWarning: true,
		dangerouslySetInnerHTML: { __html: shell_default }
	});
}
//#endregion
export { Home as component };
