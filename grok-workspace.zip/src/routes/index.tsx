import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import shell from "../f1/shell.html?raw";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  useEffect(() => {
    let dead = false;
    let stop = () => {};
    import("../f1/engine.js").then((mod) => {
      if (dead) return;
      stop = mod.startApp();
    });
    return () => {
      dead = true;
      stop();
    };
  }, []);

  return <div suppressHydrationWarning dangerouslySetInnerHTML={{ __html: shell }} />;
}
