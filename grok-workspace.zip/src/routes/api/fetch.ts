import { createFileRoute } from "@tanstack/react-router";

const HOSTS = new Set([
  "api.jolpi.ca",
  "api.open-meteo.com",
  "en.wikipedia.org",
  "api.rss2json.com",
  "news.google.com",
  "de.motorsport.com",
  "www.motorsport.com",
  "raw.githubusercontent.com",
  "cdn.jsdelivr.net",
]);

const MAX_BYTES = 5_000_000;

function bad(status: number) {
  return Response.json({ status, text: "" });
}

async function fetchAllowlisted(target: string, hops = 0): Promise<Response> {
  if (hops > 3) throw new Error("redirect");
  const parsed = new URL(target);
  if (parsed.protocol !== "https:" || !HOSTS.has(parsed.hostname)) throw new Error("host");
  const upstream = await fetch(parsed.toString(), {
    redirect: "manual",
    signal: AbortSignal.timeout(12000),
    headers: { accept: "*/*", "user-agent": "F1Zeiten/1.0" },
  });
  if (upstream.status >= 300 && upstream.status < 400) {
    const loc = upstream.headers.get("location");
    if (!loc) throw new Error("redirect");
    return fetchAllowlisted(new URL(loc, parsed).toString(), hops + 1);
  }
  return upstream;
}

export const Route = createFileRoute("/api/fetch")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const target = new URL(request.url).searchParams.get("url") ?? "";
        try {
          const upstream = await fetchAllowlisted(target);
          const buf = await upstream.arrayBuffer();
          if (buf.byteLength > MAX_BYTES) return bad(413);
          return Response.json({
            status: upstream.status,
            text: new TextDecoder().decode(buf),
          });
        } catch {
          return bad(502);
        }
      },
    },
  },
});
